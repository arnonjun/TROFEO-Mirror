import time,threading,hid
from flask import Flask,request,jsonify
VID,PID,W,H=0x0416,0x5302,1280,480
MAGIC=b"\xDA\xDB\xDC\xDD"; app=Flask(__name__)
lock=threading.Lock(); dev=None
state={"connected":False,"frames":0,"fps":0.0,"last_error":""}; t0=time.perf_counter()
def pack(j):
 h=bytearray(20);h[:4]=MAGIC;h[8:10]=W.to_bytes(2,"little");h[10:12]=H.to_bytes(2,"little");h[12:16]=(2).to_bytes(4,"little");h[16:20]=len(j).to_bytes(4,"little")
 f=bytes(h)+j;return f+b"\0"*((512-len(f)%512)%512)
def open_dev():
 global dev
 if dev:return
 d=hid.device();d.open(VID,PID);d.set_nonblocking(False)
 p=bytearray(512);p[:4]=MAGIC;p[12]=1;d.write(b"\0"+p);time.sleep(.06)
 r=bytes(d.read(512,1000))
 if len(r)<20 or r[:4]!=MAGIC:d.close();raise RuntimeError("TROFEO handshake failed")
 dev=d;state["connected"]=True
def send(j):
 global dev,t0
 with lock:
  try:
   open_dev();f=pack(j)
   for i in range(0,len(f),512):
    if dev.write(b"\0"+f[i:i+512])<=0:raise RuntimeError("USB write failed")
   state["frames"]+=1;dt=time.perf_counter()-t0
   if dt>0:state["fps"]=round(state["frames"]/dt,2)
  except Exception as e:
   state["last_error"]=str(e);state["connected"]=False
   try:
    if dev:dev.close()
   except:pass
   dev=None;raise
@app.post("/frame")
def frame():
 j=request.data
 if not j:return ("no frame",400)
 try:send(j);return ("ok",200)
 except Exception as e:return (str(e),500)
@app.get("/status")
def status():
 found=any(x.get("vendor_id")==VID and x.get("product_id")==PID for x in hid.enumerate())
 return jsonify(trofeo_found=found,**state)
if __name__=="__main__":
 print("TROFEO v1.1 S25 Screen Mirror Bridge")
 print("Keep this window open. Android app sends frames to port 8765.")
 app.run(host="0.0.0.0",port=8765,threaded=True)
