plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.tsk.trofeomirror"; compileSdk=35
 defaultConfig { applicationId="com.tsk.trofeomirror"; minSdk=30; targetSdk=35; versionCode=11; versionName="1.1" }
}
dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0"); implementation("com.squareup.okhttp3:okhttp:4.12.0") }
