TROFEO S25 SCREEN MIRROR v1.1
เป้าหมาย:
S25 เปิดแอปเพลง/วิดีโอ -> เสียงออกจาก S25 ตามปกติ -> ภาพหน้าจอ S25 ส่ง Wi-Fi ไป PC -> USB ไป TROFEO

PC:
1 ปิด TRCC / InfoPanel / Bridge รุ่นเก่า
2 ต่อ TROFEO กับ PC
3 เปิด PC_Bridge/START_BRIDGE.bat

Android:
โปรเจกต์ Android_App สำหรับ build APK ผ่าน Android Studio/GitHub Actions
เปิดแอป ใส่ PC IP แล้ว START SCREEN MIRROR
Android จะถามอนุญาตแชร์หน้าจอ ให้กด Start now
จากนั้นเปิด YouTube/YouTube Music/แอปวิดีโอที่ต้องการ
เสียงไม่ได้ถูกดักหรือส่งผ่าน Bridge จึงยังออกจาก S25/Bluetooth ตามปกติ

ข้อจำกัด:
แอปที่ป้องกันการ capture/DRM อาจแสดงจอดำบน TROFEO แม้ภาพบน S25 จะเล่นตามปกติ
v1.1 เป็นการทดสอบ Screen Mirror + local audio; ยังไม่ใช่ APK ที่ compile แล้ว
